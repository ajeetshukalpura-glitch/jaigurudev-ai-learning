import "dotenv/config";
import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-5";

if (!process.env.OPENAI_API_KEY) {
  console.warn("WARNING: OPENAI_API_KEY is not configured.");
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const allowedOrigins = (process.env.FRONTEND_ORIGIN || "")
  .split(",").map(v => v.trim()).filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    return callback(new Error("CORS origin not allowed"));
  }
}));

app.use(express.json({ limit: "32kb" }));
app.use(express.static("public"));

const limiter = rateLimit({
  windowMs: 60 * 1000,
  limit: Number(process.env.RATE_LIMIT || 30),
  standardHeaders: "draft-8",
  legacyHeaders: false
});
app.use("/api/", limiter);

const SYSTEM_PROMPT = `आप Jaigurudev AI Learning के AI शिक्षक हैं।
सरल, स्पष्ट और परीक्षा-उपयोगी हिंदी में उत्तर दें।
विद्यार्थी की कक्षा और विषय के अनुसार समझाएँ।
जहाँ उचित हो headings, bullets, उदाहरण, MCQ और अभ्यास प्रश्न दें।
अनिश्चित तथ्य को निश्चित रूप में न बताएं।`;

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    service: "Jaigurudev AI Learning",
    model: MODEL,
    aiConfigured: Boolean(process.env.OPENAI_API_KEY)
  });
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string"
      ? req.body.message.trim()
      : "";

    if (!message) {
      return res.status(400).json({ error: "message आवश्यक है।" });
    }

    if (message.length > 8000) {
      return res.status(400).json({ error: "प्रश्न बहुत लंबा है।" });
    }

    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI API key configured नहीं है।" });
    }

    const response = await client.responses.create({
      model: MODEL,
      instructions: SYSTEM_PROMPT,
      input: message
    });

    return res.json({
      reply: response.output_text || "उत्तर उपलब्ध नहीं है।"
    });
  } catch (error) {
    console.error("AI API error:", error);
    return res.status(500).json({ error: "AI सेवा से उत्तर प्राप्त नहीं हो सका।" });
  }
});

app.get("*", (req, res) => {
  res.sendFile("index.html", { root: "public" });
});

const server = app.listen(PORT, "0.0.0.0", () => {
  console.log(`Jaigurudev AI Learning running on port ${PORT}`);
});

process.on("SIGTERM", () => server.close(() => process.exit(0)));
