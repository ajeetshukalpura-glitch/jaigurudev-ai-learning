# Jaigurudev AI Learning — FINAL

## Features
- AI Teacher using OpenAI Responses API
- Hindi-first educational system prompt
- Notes / subject navigation
- MCQ prompt generator
- Quiz mode
- Responsive mobile UI
- Express backend
- API rate limiting
- Health check
- Production PORT support
- API key kept server-side

## Local setup

```bash
npm install
```

Create `.env` from `.env.example`:

```env
OPENAI_API_KEY=YOUR_OPENAI_API_KEY
OPENAI_MODEL=gpt-5
PORT=3000
FRONTEND_ORIGIN=
RATE_LIMIT=30
NODE_ENV=production
```

Then:

```bash
npm start
```

Open:

```text
http://localhost:3000
```

## API

`POST /api/chat`

```json
{
  "message": "कक्षा 12 समाजशास्त्र में सामाजिक स्तरीकरण समझाओ"
}
```

`GET /api/health`

## Render deployment

- Build Command: `npm install`
- Start Command: `npm start`
- Add `OPENAI_API_KEY` in Render Environment Variables.
- Add `OPENAI_MODEL=gpt-5`.
- Do not commit `.env`.

## Important
This is a production-ready starter, not a complete school ERP. Student authentication, persistent database, payment gateway, teacher/admin permissions, file storage and analytics should be added before using it as a full commercial platform.
